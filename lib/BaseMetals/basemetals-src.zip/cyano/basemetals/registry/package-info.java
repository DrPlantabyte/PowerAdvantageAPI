/**
This package contains registry classes for registering content related to 
PowerAdvantage.
*/
package cyano.basemetals.registry;